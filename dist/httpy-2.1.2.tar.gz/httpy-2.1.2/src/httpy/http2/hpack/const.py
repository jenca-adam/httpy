YES, NO, NEVER = range(3)

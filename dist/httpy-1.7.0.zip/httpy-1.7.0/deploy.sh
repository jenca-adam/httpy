python setup.py sdist bdist bdist_wheel

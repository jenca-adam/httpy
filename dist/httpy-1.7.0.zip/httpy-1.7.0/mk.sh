./runtests.sh
./deploy.sh
cd docs/source
./mklao.sh


httpy module
============

.. automodule:: httpy
   :members:
   :undoc-members:
   :show-inheritance:

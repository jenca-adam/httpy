
A lightweight socket-based library to create HTTP(s) connections.
## Features
   * Cookies support
   * Caching support
   * Easy debugging
   * HTTP authentication
   * Form support



Docs at <https://httpy.readthedocs.io/>

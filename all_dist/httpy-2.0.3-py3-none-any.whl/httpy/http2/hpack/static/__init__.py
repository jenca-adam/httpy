from .__huffman_table import HUFFMAN_TABLE, HUFFMAN_TABLE_DICT
from .__static_table import STATIC_TABLE


A lightweight socket-based library to create HTTP(s) and WebSocket connections.
## Features
   * Cookies support
   * Caching support
   * Easy debugging
   * HTTP authentication
   * Form support
   * JSON support
   * Connection pooling
   * Session support	



Docs at <https://httpy.readthedocs.io/>
